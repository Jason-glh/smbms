package cn.smbms.test;

import java.util.Date;

import cn.smbms.pojo.User;

public class Test {
	public static void main(String[] args) {
	}
}
