
/**
 * mybatis的类
 * @author luoxiang
 *
 */
package cn.gson.oasys.mappers;