
/**
 * 通知公告管理dao层
 * @author luoxiang
 *
 */
package cn.gson.oasys.model.dao.informdao;