
/**
 * 公告通知模块
 * @author luoxiang
 *
 */
package cn.gson.oasys.model.entity.notice;