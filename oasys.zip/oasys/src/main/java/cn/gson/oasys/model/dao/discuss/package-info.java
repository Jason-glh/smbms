
/**
 * 讨论区dao
 * @author luoxiang
 *
 */
package cn.gson.oasys.model.dao.discuss;