
/**
 * dao层
 * @author luoxiang
 *
 */
package cn.gson.oasys.model.dao;