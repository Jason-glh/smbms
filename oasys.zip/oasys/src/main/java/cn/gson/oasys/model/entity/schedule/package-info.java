/**
 * 日程模块
 * 
 * @author Administrator
 *
 */
package cn.gson.oasys.model.entity.schedule;